Linux OS package build source

The shared_app/ directory is a separate copy of the Flutter app source, including linux/ platform files. scripts/package_linux_deb.sh is included for .deb packaging. Build output is not included.
