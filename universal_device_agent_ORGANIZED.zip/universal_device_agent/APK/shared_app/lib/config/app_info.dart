/// Item 88/89: product naam + version ek jagah (About / Diagnostics mein).
/// `kAppVersion` ko `pubspec.yaml` ke `version:` ke saath sync rakhein.
library;

const String kProductName = 'Universal Device Agent';
const String kAppVersion = '0.1.0';
