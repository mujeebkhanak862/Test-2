Android APK build source

The shared_app/ directory is a separate copy of the Flutter app source, including android/ platform files. Build output is not included; use the repository GitHub Actions workflow or a configured Flutter/Android build environment.
